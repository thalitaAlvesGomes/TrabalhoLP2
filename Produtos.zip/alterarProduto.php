<?php
    session_start();
    if ($_SESSION['tipoUsuario'] == 1) {
        if(isset($_POST['codigo'])&&
        isset($_POST['nome']) &&
        isset( $_POST['valorAtacado']) &&
        isset($_POST['valorVarejo'] ) &&
        isset($_POST['quantidade'] )){

        $var_codigo = $_POST['codigo'];
        $var_nome = $_POST['nome'];
        $var_valorAtacado = $_POST['valorAtacado']; 
        $var_valorVarejo = $_POST['valorVarejo']; 
        $var_quantidade = $_POST['quantidade']; 
        require_once "../conexao.php";
        try
            {   
                // atualizar na tabela
                $sql="update produtos set 
                    nome ='$var_nome',
                    valorAtacado ='$var_valorAtacado',
                    valorVarejo ='$var_valorVarejo',
                    quantidade ='$var_quantidade'
                    where codigo =$var_codigo";
                $query=$conexao->prepare($sql);
                $query->execute();
                header("location:listaProd.php");
            }
        catch (PDOException $i)
        {
            //se houver exceção, exibe
            die("Erro: <code>" . $i->getMessage() . "</code>");
        }
    }
    //fim do if
    }
    ?>